<?php

namespace App\Types;

class VerificationCodeType
{
    public const REGISTRATION_CODE = "registration";
    public const RESET_PASSWORD_CODE = 'reset_password';
}
