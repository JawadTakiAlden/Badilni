<?php

namespace App\Types;

class ImageFlag
{
    public const DELETE = -1;
    public const ADD = 1;
    public const UPDATE_IS_DEFAULT = 0;
}
