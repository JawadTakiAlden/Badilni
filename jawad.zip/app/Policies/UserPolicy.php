<?php

namespace App\Policies;

use App\Models\User;
use App\Types\UserType;

class UserPolicy
{
    /**
     * Create a new policy instance.
     */
    public function __construct()
    {
        //
    }
}
