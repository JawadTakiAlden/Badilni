<div class="text-center">
    <h3 >Hello</h3>
    
    <p>Thanks for your registration,Please insert the code below to activation page in application.</p>
    <p><b><?php echo e($data["code"]); ?></b></p>
</div>





<?php if(! empty($salutation)): ?>
<?php echo e($salutation); ?>

<?php else: ?>
<?php echo app('translator')->get('Best regards'); ?>,<br />Padilni Team
<?php endif; ?>


<?php /**PATH C:\Users\jawad\Desktop\new_badilni\resources\views/mails/activation.blade.php ENDPATH**/ ?>